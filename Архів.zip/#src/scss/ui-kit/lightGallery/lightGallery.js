$(".lightGallery").lightGallery({
  share: false,
  autoplay: false,
  getCaptionFromTitleOrAlt: false,
  autoplayControls: false
});